<!--
=========================================================
* Material Dashboard 2 - v3.0.4
=========================================================

* Product Page: https://www.creative-tim.com/product/material-dashboard
* Copyright 2022 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://www.creative-tim.com/license)
* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
-->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <title>
    National ID
  </title>
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />
  <!-- Nucleo Icons -->
  <link href="../assets/css/nucleo-icons.css" rel="stylesheet" />
  <link href="../assets/css/nucleo-svg.css" rel="stylesheet" />
  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
  <!-- Material Icons -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
  <!-- CSS Files -->
  <link id="pagestyle" href="../assets/css/material-dashboard.css?v=3.0.4" rel="stylesheet" />
</head>

<body class="">
  <div class="container position-sticky z-index-sticky top-0">
    <div class="row">
      <div class="col-12">

      </div>
    </div>
  </div>
  <main class="main-content  mt-0">
    <section>
      <div class="page-header min-vh-100">
        <div class="container">
          <div class="row">
            <div class="col-6 mx-auto">
              <div class="card card-plain">
                <div class="card-header">
                  <h4 class="font-weight-bolder">Add a product</h4>
                </div>
                <div class="card-body">
                  <form id="citizen" role="form">
                    <div class="input-group input-group-outline mb-3">
                      <label class="form-label">Name</label>
                      <input required name="name" type="text" class="form-control">
                    </div>
                    <div class="input-group input-group-outline mb-3">
                      <label class="form-label">Price (ZWL)</label>
                      <input required name="price" type="text" class="form-control">
                    </div>
                    <div class="input-group input-group-outline mb-3">
                      <label>Description</label>
                      <textarea required name="description" rows="5" type="text" class="form-control mt-3"></textarea>
                    </div>
                    <div class="input-group input-group-outline mb-3">
                      <label>Image</label>
                      <input required id="image"  name="image" type="file" class="form-control mt-3" onchange="previewImage()">
                    </div>
                    <div class="input-group input-group-outline mb-3">
                      <!-- <label class="form-label">Image Preview</label> -->
                      <img id="image-preview" alt="" style="max-width: 100%; max-height: 200px;">
                    </div>
                    <div class="input-group input-group-outline mb-3">
                      <label>Pharmacy</label>
                      <select class="form-control form-select mt-3" id="pharmacy">
                      <?php
                      require '../vendor/autoload.php';
                      require './dbconfig.php';

                      $db = new \Buki\Pdox($config);

                      $result = $db->table('pharmacies')->getAll();
                      foreach ($result as $row) {
                        echo '<option value="' . $row->id . '">' . $row->name . '</option>';
                      }
                      ?>
                    </select>
                    </div>
                    
                  
                    <div class="text-center">
                      <button type="submit" class="btn btn-lg bg-gradient-primary btn-lg w-100 mt-4 mb-0">Submit</button>
                      <a href="./tables.php" class="btn btn-lg bg-gradient-secondary btn-lg w-100 mt-4 mb-0">Back</a>
                    </div>
                  </form>


                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
  <!--   Core JS Files   -->
  <script src="../assets/js/jquery.min.js"></script>
  <script src="../assets/js/core/popper.min.js"></script>
  <script src="../assets/js/core/bootstrap.min.js"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.min.js"></script>
  <script src="../assets/js/plugins/smooth-scrollbar.min.js"></script>
  <script>
    function previewImage() {
      const preview = document.getElementById('image-preview');
      const file = document.getElementById('image').files[0];
      const reader = new FileReader();

      reader.addEventListener("load", function() {
        preview.src = reader.result;
      }, false);

      if (file) {
        reader.readAsDataURL(file);
      }
    }

    // $(document).ready(function() {
    $('#citizen').submit(function(event) {
      event.preventDefault();

      // Get the form data
      var formData = new FormData(this);
      formData.append('pharmacy', $('#pharmacy').val());
      // // Send the form data to the server using AJAX
      $.ajax({
        type: 'POST',
        url: 'add-product.php', // Replace with the actual path to your PHP script
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
          console.log(response)
          alert(response); // Display the response message
        },
        error: function(xhr, status, error) {
          alert('An error occurred: ' + error); // Display the error message
        }
      });
    });
    // });
  </script>
  <script>

  </script>
  <script>
    var win = navigator.platform.indexOf('Win') > -1;
    if (win && document.querySelector('#sidenav-scrollbar')) {
      var options = {
        damping: '0.5'
      }
      Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
    }
  </script>
  <!-- Github buttons -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="../assets/js/material-dashboard.min.js?v=3.0.4"></script>
</body>

</html>