<?php

$auth = new Auth('localhost', "root", "", "skinlesion");
