<?php
require '../vendor/autoload.php';

require './dbconfig.php';

$db = new \Buki\Pdox($config);

$result = $db->table('pharmacies')->getAll();
echo json_encode($result);