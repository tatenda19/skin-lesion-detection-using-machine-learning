<?php
$config = [
	'driver'    => 'mysql',
	'host'      => 'localhost',
	'database'  => "u868591432_pharmasearch",
	'username'  => "u868591432_pharmauser",
	'password'  => "M2Wlpq0oe=u",
	'charset'   => 'utf8',
	'collation' => 'utf8_general_ci',
	'prefix'    => '',
	'options'   => []
];
require '../vendor/autoload.php';
require './dbconfig.php';

$db = new \Buki\Pdox($config);


$db->table('test')->like('title', "%php%")->getAll();