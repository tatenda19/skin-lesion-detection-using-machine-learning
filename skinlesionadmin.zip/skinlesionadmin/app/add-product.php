<?php
require '../vendor/autoload.php';
require './dbconfig.php';

// Initialize the PDOx object
$db = new \Buki\Pdox($config);

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Get the form data
  $name = $_POST['name'];
  $price = $_POST['price'];
  $description = $_POST['description'];
  $pharmacy = $_POST['pharmacy'];
  $image = $_FILES['image'];

  // Upload the product image to the server
  $target_dir = 'product_images/';
  $target_file = $target_dir . basename($image['name']);
  if (move_uploaded_file($image["tmp_name"], $target_file)) {
    // Insert the product data into the database
    $image_path = $target_file;
    $product_data = [
      'name' => $name,
      'price' => $price,
      'description' => $description,
      'image' => $image_path,
      'pharmacy'=>$pharmacy
    ];
    // echo json_encode($product_data);
    $result = $db->table('products')->insert($product_data);
    if ($result > 0) {
      echo 'The product has been added successfully.';
    } else {
      echo 'Failed to add the product.';
    }
  } else {
    echo 'Sorry, there was an error uploading your file.';
  }
}
?>