<?php
require '../vendor/autoload.php';
require './dbconfig.php';


$db = new \Buki\Pdox($config);


echo $db->table('products')->where("id", $_POST['id'])->delete();




