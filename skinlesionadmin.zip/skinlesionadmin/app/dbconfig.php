<?php
$config = [
	'driver'    => 'mysql',
	'host'      => 'localhost',
	'database'  => "u868591432_skinlesion",
	'username'  => "u868591432_skinlesionuser",
	'password'  => '3NQKYPHNRJ?g',
	'charset'   => 'utf8',
	'collation' => 'utf8_general_ci',
	'prefix'    => '',
	'options'   => []
];
