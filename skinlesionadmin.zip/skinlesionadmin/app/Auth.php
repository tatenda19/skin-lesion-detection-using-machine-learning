<?php
class Auth
{
    private $db;
    function __construct($host, $username, $password, $database)
    {
        // Create a new PDO instance
        try {
            $dsn = "mysql:host=$host;dbname=$database";
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ];
            $this->db = new PDO($dsn, $username, $password, $options);
        } catch (PDOException $e) {
            die("Database connection failed: " . $e->getMessage());
        }
    }

    function signup($email, $firstname, $surname, $password)
    {
        // Validate input
        if (empty($email) || empty($firstname) || empty($surname) || empty($password)) {
            return "All fields are required";
        }

        // Check if email already exists in the database
        $stmt = $this->db->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user) {
            return "Email already exists";
        }

        // Hash the password
        $hash = password_hash($password, PASSWORD_DEFAULT);

        // Insert the user into the database
        $stmt = $this->db->prepare("INSERT INTO users (email, firstname, surname, password) VALUES (?, ?, ?, ?)");
        $stmt->execute([$email, $firstname, $surname, $hash]);

        return null; // No error
    }

    function login($email, $password)
    {
        // Validate input
        if (empty($email) || empty($password)) {
            return "Email and password are required";
        }

        // Check if email exists in the database
        $stmt = $this->db->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user) {
            return "Invalid email or password";
        }

        // Verify the password
        if (!password_verify($password, $user['password'])) {
            return "Invalid email or password";
        }

        // Set session variables
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_firstname'] = $user['firstname'];
        $_SESSION['user_surname'] = $user['surname'];

        return null; // No error
    }

    function logout()
    {
        // Unset all session variables
        $_SESSION = array();

        // Delete the session cookie
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params["path"],
                $params["domain"],
                $params["secure"],
                $params["httponly"]
            );
        }

        // Destroy the session
        session_destroy();
    }

    function getOwnerByLicensePlate($licensePlate)
    {
        $stmt = $this->db->prepare("SELECT * FROM vehicle_owners 
                                    JOIN vehicles ON vehicle_owners.id = vehicles.owner_id 
                                    WHERE vehicles.license_plate = ?");
        $stmt->execute([$licensePlate]);
        return $stmt->fetch();
    }

    public function registerVehicle($licensePlate, $ownerName, $ownerEmail, $ownerPhone)
    {
        // First, check if the vehicle is already registered
        $stmt = $this->db->prepare("SELECT COUNT(*) FROM vehicles WHERE license_plate = ?");
        $stmt->execute([$licensePlate]);
        $count = $stmt->fetchColumn();

        if ($count > 0) {
            throw new Exception('Vehicle with this license plate is already registered');
        }

        // Insert the vehicle and owner details into the database
        $stmt = $this->db->prepare("INSERT INTO vehicles (license_plate, time_in, time_out) VALUES (?, NULL, NULL)");
        $stmt->execute([$licensePlate]);
        $vehicleId = $this->db->lastInsertId();

        $stmt = $this->db->prepare("INSERT INTO vehicle_owners (vehicle_id, owner_name, owner_email, owner_phone) VALUES (?, ?, ?, ?)");
        $stmt->execute([$vehicleId, $ownerName, $ownerEmail, $ownerPhone]);

        return true;
    }

    public function deleteVehicle($licensePlate)
    {
        // First, get the vehicle ID
        $stmt = $this->db->prepare("SELECT id FROM vehicles WHERE license_plate = ?");
        $stmt->execute([$licensePlate]);
        $vehicleId = $stmt->fetchColumn();

        if (!$vehicleId) {
            throw new Exception('Vehicle not found');
        }

        // Delete the vehicle and its corresponding owner
        $stmt = $this->db->prepare("DELETE FROM vehicles WHERE id = ?");
        $stmt->execute([$vehicleId]);

        $stmt = $this->db->prepare("DELETE FROM vehicle_owners WHERE vehicle_id = ?");
        $stmt->execute([$vehicleId]);

        return true;
    }


    function logTimeIn($licensePlate)
    {
        // Get the current date and time
        $entryTime = date('Y-m-d H:i:s');

        // Insert a new entry in the vehicle_entries table
        $stmt = $this->db->prepare('INSERT INTO vehicle_entries (license_plate, entry_time) VALUES (:licensePlate, :entryTime)');
        $stmt->bindParam(':licensePlate', $licensePlate);
        $stmt->bindParam(':entryTime', $entryTime);
        $stmt->execute();
    }

    function logTimeOut($licensePlate)
    {
        // Get the current date and time
        $exitTime = date('Y-m-d H:i:s');

        // Insert a new entry in the vehicle_exits table
        $stmt = $this->db->prepare('INSERT INTO vehicle_exits (license_plate, exit_time) VALUES (:licensePlate, :exitTime)');
        $stmt->bindParam(':licensePlate', $licensePlate);
        $stmt->bindParam(':exitTime', $exitTime);
        $stmt->execute();
    }

    public function isVehicleRegistered($licensePlate) {
        $stmt = $this->db->prepare('SELECT COUNT(*) FROM vehicles WHERE license_plate = :licensePlate');
        $stmt->execute(['licensePlate' => $licensePlate]);
        $count = $stmt->fetchColumn();
        return $count > 0;
    }
    
}
