<?php
require '../vendor/autoload.php';

require './dbconfig.php';

$db = new \Buki\Pdox($config);

$result = $db->table('logs')->getAll();
echo json_encode($result);

// address
// : 
// "77 Leopold Takawira St, Harare"
// description
// : 
// "jnbkjnbjkn"
// hours
// : 
// "9am - 5:30pm"
// id
// : 
// 4
// image
// : 
// "product_images/tcfl-favicon-32x32.png"
// latitude
// : 
// " -17.83393861949215"
// longitude
// : 
// " 31.045003020624808"
// name
// : 
// "Regent Pharmacy"
// pharmacy
// : 
// "4"
// phone
// : 
// "(024) 2756015"
// price
// : 
// "0.00"